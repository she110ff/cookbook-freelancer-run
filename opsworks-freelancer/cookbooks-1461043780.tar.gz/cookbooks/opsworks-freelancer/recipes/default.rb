include_recipe 'build-essential'


app = search(:aws_opsworks_app).first
app_path = "/srv/#{app['shortname']}"


package 'git' do
  options '--force-yes' if node['platform'] == 'ubuntu' && node['platform_version'] == '14.04'
end

package 'libjpeg-dev' #for image
package 'libpq-dev' #for postgres
package 'memcached'

application app_path do
  git app_path do
    repository app['app_source']['url']
    action :sync
  end

  python '3'
  virtualenv
  pip_requirements

  file ::File.join(app_path, 'freelancer', 'sse.py') do
    content "\n
    \nfrom freelancer.setting_cache import *\n
    \nAWS_STORAGE_BUCKET_NAME = 'freelancer.site' \n
    \nAWS_ACCESS_KEY_ID = 'AKIAJ66WWTR2CUZNR2XA' \n
    \nAWS_SECRET_ACCESS_KEY = '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' \n
    \nAWS_QUERYSTRING_AUTH = AWS_S3_SECURE_URLS = False \n

    \nSECRET_KEY = 'h5c%ats796i*rvkt^3=x82fkax299e*l44h8!auphz8@*daqh5'\n
    \nNEVERCACHE_KEY = '7_l!k&01ymk3zqrxuubn$(pawcwacl+-7vi@&0$#yo*#lu6(-$'\n"
  end

  file ::File.join(app_path, 'freelancer', 'deploy.py') do
     content "from freelancer.settings import *\nfrom freelancer.sse import *\n"
  end

  django do
    allowed_hosts ['localhost', node['cloud']['public_ipv4'], node['fqdn']]
    settings_module 'freelancer.deploy'

    database do
      engine 'postgres'
      host 'freelancer-site-staging-2.c8fpeykydydy.ap-northeast-1.rds.amazonaws.com'
      port '5432'
      user 'staging_master'
      password 'staging-71la77'
      name 'main_db'
    end

    syncdb false
    collectstatic false
    migrate true
    debug true
  end

  gunicorn
end
