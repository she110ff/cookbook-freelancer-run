include_recipe "route53"


Chef::Log.info("********** The app's initial state is '#{node[:opsworks_route53][:zone_id]}' **********")
z_id = node[:opsworks_route53][:zone_id]
domain = node[:opsworks_route53][:domainname]
subdomain = node[:opsworks][:stack][:name].downcase.strip.gsub(' ', '-').gsub(/[^\w-]/, '-')

domain = node[:opsworks_route53][:prepend_stack_name] ? "#{subdomain}.#{domain}" : domain

route53_record "create a record" do
  name      "#{node[:opsworks][:instance][:hostname]}.#{domain}"
  value     node[:opsworks][:instance][:public_ip]
  type      "A"
  ttl       node[:opsworks_route53][:ttl]
  zone_id               node[:dns_zone_id]
  aws_access_key_id     node[:custom_access_key]
  aws_secret_access_key node[:custom_secret_key]
  overwrite true
  action    :create
end
