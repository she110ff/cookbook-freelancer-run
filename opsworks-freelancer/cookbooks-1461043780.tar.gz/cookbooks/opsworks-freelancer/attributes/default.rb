case node['platform_family']
when 'rhel'
  if node['platform_version'].to_i >= 7 && node['platform'] != 'amazon'
    default['django-demo']['mysql_package_name'] = 'mariadb-devel'
  else
    default['django-demo']['mysql_package_name'] = 'mysql-devel'
  end
when 'debian'
  default['django-demo']['mysql_package_name'] = 'libmysqlclient-dev'
end


default[:opsworks_route53][:domainname] = node[:opsworks][:stack][:domainname] if node[:opsworks] && node[:opsworks][:stack] && node[:opsworks][:stack][:domainname]
default[:opsworks_route53][:prepend_stack_name] = true
default[:opsworks_route53][:ttl] = 300
