# Poise-Archive Changelog

## v1.1.2

* Fix compat with older Ruby that doesn't include `Entry#symlink?`.

## v1.1.1

* Fix GNU tar longlink extension.

## v1.1.0

* Scrap the original tar implementation in favor of a 100% pure-Ruby solution.
  This should work on all platforms exactly the same. Hopefully.

## v1.0.0

* Initial release!
